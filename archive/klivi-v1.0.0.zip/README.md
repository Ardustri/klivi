# klivi

## "Hate write desktop app in native?, We too, then just use klivi!"

# install klivi

py

```
pip3 install klivi
```

#then create a html file called view.html with this content

html

```
<window>
<text>hello world</text>
<window>
```

# on the command line, run

bash```
klivi view.html

```

```
