from colorama import Fore, Style, init
from klivi.utils.period import get_current_hour
init(autoreset=True)


def log(log_type:str, message:str, fore:Fore):
    print(f"{Style.BRIGHT}{fore}[{get_current_hour()}] [{log_type}] {message}")


def info(message:str):
    log("Info", message, Fore.BLUE)


def warn(message:str):
    log("Warning", message, Fore.YELLOW)


def error(message:str):
    log("Error", message, Fore.RED)
    quit()


def succeed(message:str):
    log("Log", message, Fore.GREEN)


def debug(message:str):
    log("Debug", message, Fore.MAGENTA)
