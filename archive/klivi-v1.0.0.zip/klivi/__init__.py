__all__ = []
__name__ = "klivi"
__author__ = "Ardustri"
__version__ = "1.0.0"
__license__ = "MPL-2.0"
