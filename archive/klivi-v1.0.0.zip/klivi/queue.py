from typing import Any, List


class Queue:
    def __init__(self):
        self.queue = []

    def enqueue(self, item) -> True:
        self.queue.append(item)
        return True

    def dequeue(self) -> Any:
        if len(self.queue) < 1:
            return None
        return self.queue.pop(0)

    def get_queue(self) -> List[Any]:
        return self.queue

    def size(self) -> int:
        return len(self.queue)
