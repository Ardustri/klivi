class Parser:
    def __init__(self, source: dict) -> None:
        self.source = source
