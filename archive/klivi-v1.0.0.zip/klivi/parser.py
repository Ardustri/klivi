class Parser:
    def __init__(self, source):
        self.source = source

    def render(self):
        ...
