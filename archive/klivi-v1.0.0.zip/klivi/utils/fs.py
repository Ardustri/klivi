import os


def write_file(filename: str, content: str, mode="w") -> None:
    file = open(filename, mode)
    file.write(content)
    file.close()


def read_file(filename: str, mode="r") -> str:
    file = open(filename, mode)
    file_content = file.read()
    file.close()
    return file_content


def is_exist(name: str) -> bool:
    if os.path.exists(name):
        return True
    else:
        return False


def mkdir(folder_name: str) -> None:
    if is_exist(folder_name):
        print("The folder is already exist")
    else:
        os.mkdir(folder_name)


def rmdir(folder_name: str) -> None:
    if is_exist(folder_name):
        os.rmdir(folder_name)
    else:
        print("The folder does not exist")
