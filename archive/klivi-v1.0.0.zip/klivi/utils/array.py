import toga
from typing import Any, List


def pops(array: list, count: int) -> List[Any]:
    return [array.pop() for _ in count]
