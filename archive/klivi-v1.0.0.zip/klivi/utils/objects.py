import sys


def get_size(object) -> int:
    return sys.getsizeof(object)
