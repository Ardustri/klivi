from typing import Any, List


class Stack:
    def __init__(self):
        self.stack = []

    def is_empty(self) -> bool:
        return len(self.stack) == 0

    def push(self, item) -> True:
        self.stack.append(item)
        return True

    def pop(self) -> Any:
        if self.is_empty():
            return False

        return self.stack.pop()


def split_word(word) -> List[str]:
    return [char for char in word]
