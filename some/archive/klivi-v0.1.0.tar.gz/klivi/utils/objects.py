import sys


def get_size(object):
    return sys.getsizeof(object)
